import  tensorflow as tf
import numpy as np
from tensorflow.contrib.seq2seq import *
from tensorflow.python.layers.core import Dense
from modules import get_token_embeddings, ff, positional_encoding, multihead_attention, label_smoothing, noam_scheme


class Lenet5_LSTM:

     def __init__(self,cnn_input_node_size,trg_vocab_size,trg_embedding,vocabs_map,batch_size,keep_prob):
         '''
         :param cnn_input_node_size:
         :param trg_vocab_size:
         :param trg_embedding:
         '''
         self.cnn_input_node_size = cnn_input_node_size
         self.channels = 1
         #全连接层的节点个数
         self.fc_size = 300
         self.rnn_hidden_size = 300#rnn中的状态层状态节点必须等于输入状态的大小
         #self.dec_cell = tf.nn.rnn_cell.MultiRNNCell([tf.nn.rnn_cell.LSTMCell(self.rnn_hidden_size) for _ in range(2)])
         self.dec_cell = tf.nn.rnn_cell.BasicLSTMCell(self.rnn_hidden_size,dtype=tf.float32)
         self.sos_id = 1
         self.eos_id = 2
         self.unk = 3
         self.pad = 0
         self.trg_vocab_size = trg_vocab_size
         self.vocabs_map = self.findVocabMap(vocabs_map)  # 词汇的编号
         #目标词汇embedding集合，大小[trg_vocab_size,每个词的embeding_size]
         self.trg_embedding = trg_embedding #tf.Variable(trg_embedding)
         self.softmax_weight = tf.get_variable(name="softmax_weight",shape = [self.rnn_hidden_size,self.trg_vocab_size],initializer=tf.truncated_normal_initializer(stddev=0.1))
         self.softmax_bias = tf.get_variable(name="softmax_bias",shape=[self.trg_vocab_size],initializer=tf.constant_initializer(0.0))
         # transformer 的配置
         self.num_heads = 6
         self.keep_prob = keep_prob
         self.batch_size = batch_size
         self.max_sentence_length = 7
         # attention 机制需要用的大小
         self.attention_size = 300
         # 表示我们组合多少个向量的个数
         self.current_vec_nums = 2

     def inference(self, input_tensor, input_tensor_size, rnn_input_tensor, rnn_input_tensor_size, regularizer, train):
         '''
         input_tensor: 输入向量 从数据集中读取来的，然后batch*4d
         input_tensor_size:由于4d不知道多少，需要传入进来
         rnn_intput_tensor: 这个是rnn的输入向量
         rnn_input_tensor_size:每个句子具体的大小 维度一维 batch_size大小
         :return:
         '''
         struct_embedding,jimple_embedding,natural_embedding = tf.split(input_tensor,3,axis=1)
         input_tensor = tf.concat((jimple_embedding,natural_embedding),axis=1) #【batch_size,600】
         #input_tensor = natural_embedding
         # 开始全连接层和注意力机制 input_tensor 的维度 batch_size * 组合向量的维度4d
         with tf.variable_scope("input/full-connect", reuse=tf.AUTO_REUSE):
             full_weights = tf.get_variable(name="TRANSFORM",
                                            shape=[input_tensor_size, self.current_vec_nums * self.attention_size],
                                            dtype=tf.float32, initializer=tf.truncated_normal_initializer(stddev=0.1))
             flat_embed = tf.tanh(tf.matmul(input_tensor, full_weights))  # result： batch_size*900
             flat_embed = tf.reshape(flat_embed, [self.batch_size, self.current_vec_nums,
                                                  self.attention_size])  # 变形一下 [batch_size,3,300]
             #attention机制[batch_size,3,300]
             memory= self.transformer_attention_enc(flat_embed,train)

         #后面接上transformer的mask_attention
         if train:
             #[batch_size,t,300]
             rnn_input_tensor_embedding = tf.nn.embedding_lookup(self.trg_embedding, rnn_input_tensor)
             for i in range(1):
                 #[batch_size,t,300]
                 rnn_input_tensor_embedding = self.transformer_attention_dec(rnn_input_tensor_embedding,memory,train)
             #利用词表的词节省次数
             weights = tf.transpose(self.trg_embedding)  # (300, 8089)
             logits = tf.einsum('ntd,dk->ntk', rnn_input_tensor_embedding, weights)  # (N, T2, vocab_size)

             return tf.reshape(logits,[-1,self.trg_vocab_size])
         else:
             #最长生成的长度
             #开始长度为[batch_size,1]而且值都是开始符号
             rnn_input_tensor_embedding = tf.nn.embedding_lookup(self.trg_embedding, rnn_input_tensor)
             #embeding [batch_size,-1,300]
             for _ in range(self.max_sentence_length):
                 #block的次数
                 for i in range(1):
                     rnn_input_tensor_embedding = self.transformer_attention_dec(rnn_input_tensor_embedding,memory,train)
                 # 利用词表的词节省次数
                 weights = tf.transpose(self.trg_embedding)  # (300, 8089)
                 logits = tf.einsum('ntd,dk->ntk', rnn_input_tensor_embedding, weights)  # (N, T2, vocab_size)
                 #相当于这一步预测出词[batch_size,填充次数]
                 yhat = tf.to_int32(tf.argmax(logits,axis=-1))
                 #只要这一行有2就是true,全部都有2 才停
                 if tf.reduce_all(tf.reduce_any(tf.equal(yhat,2),axis=1))== True : break
                 _decoder_inputs = tf.concat((rnn_input_tensor,yhat),axis=1)
                 rnn_input_tensor_embedding = tf.nn.embedding_lookup(self.trg_embedding, _decoder_inputs)
             return yhat


     def transformer_attention_enc(self, lstm_output,train):
         '''
         输出 [batch_size,3,300]
         :param lstm_output:
         :param train:
         :return:
         '''
         # lstm_output [batch_size,lenths,512]
         dec = multihead_attention(queries=lstm_output,
                                   keys=lstm_output,
                                   values=lstm_output,
                                   num_heads=self.num_heads,
                                   dropout_rate=self.keep_prob,
                                   training=train,
                                   causality=False)
         # feed forward
         dec = ff(dec, num_units=[600, self.rnn_hidden_size])
         return dec


     def transformer_attention_dec(self, lstm_output,memory,train):
         '''
         解码器[batch_size,t,300]
         :param lstm_output:
         :param memory:
         :param train:
         :return:
         '''
         #加上位置信息
         #lstm_output += positional_encoding(lstm_output, 6)
         #lstm_output = tf.layers.dropout(lstm_output, self.keep_prob, training=train)

         dec = multihead_attention(queries=lstm_output,
                                   keys=lstm_output,
                                   values=lstm_output,
                                   num_heads=self.num_heads,
                                   dropout_rate=self.keep_prob,
                                   training=train,
                                   causality=True,scope="self_attention")
         # Vanilla attention
         dec = multihead_attention(queries=dec,
                                   keys=memory,
                                   values=memory,
                                   num_heads=self.num_heads,
                                   dropout_rate=self.keep_prob,
                                   training=train,
                                   causality=False,
                                   scope="vanilla_attention")

         # feed forward
         dec = ff(dec, num_units=[600, self.rnn_hidden_size])
         return dec


     def train(self,logits,trg_label,trg_size,butch_size,all_train_data_size,trg_vocab_size):
         '''
         logits 是[batch*num_steps,vocab_size]的大小矩阵，trglabels = [batch*num,1]
         训练模型
         :return:
         '''
         #loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=tf.reshape(trg_label,[-1]),logits=logits)
         #y_ = label_smoothing(tf.one_hot(tf.reshape(trg_label, [-1]), trg_vocab_size, 1., 0.))
         loss = tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=tf.one_hot(tf.reshape(trg_label, [-1]), trg_vocab_size, 1, 0))
         #由于每个句子长度不同，所以不同的句子的softmaxloss个数不同
         label_weights = tf.sequence_mask(trg_size,maxlen=tf.shape(trg_label)[1],dtype=tf.float32)
         label_weights = tf.reshape(label_weights,[-1])

         cost = tf.reduce_sum(loss*label_weights)
         cost_per_token = cost/tf.reduce_sum(label_weights)
         tf.summary.scalar("loss",cost_per_token)

         global_step = tf.Variable(0)
         #也就是整个数据集能够分100个batch
         #learning_rate = tf.train.exponential_decay(0.5,global_step,all_train_data_size/butch_size,0.96,staircase=True)
         learning_step = tf.train.AdadeltaOptimizer(0.1).minimize(cost_per_token,global_step)
         #learning_step = tf.train.GradientDescentOptimizer(0.1).minimize(cost_per_token, global_step)
         #tf.summary.scalar("learning_rate",learning_rate)

         return  cost_per_token,learning_step

     #解析出每个编号对应的词
     def findVocabMap(self,file):
         vocabs_map = {}
         if file != None:
             with open(file) as vocab_file:
                 datas = vocab_file.readline()
                 while (len(datas) > 0):
                     datas = datas.split()
                     vocabs_map[int(datas[1])] = datas[0]
                     datas = vocab_file.readline()
         return vocabs_map

     def test(self):
         '''
         验证模型
         :return:
         '''
         pass

     def filter_impossible_names(self, names_list):
         '''
         输入的是name的数字list [3,2,1,7]
         :param names_list:
         :return:
         '''
         result = []
         for name in names_list:
             if name not in [self.sos_id, self.eos_id, self.unk, self.pad]:
                 result.append(str(name))
         return result

     def unique(self, sequence):
         unique = []
         [unique.append(str(item)) for item in sequence if item not in unique]
         return unique

     '''
     改进评估方案 1.去除最后预测的不属于方法名字的词 比如 <sos> UNK <eos> 这里用 1,2,3 编号
     2.填充的位置的生成都不要！相当于去除填充词
     3.指标一:accuracy 生成的名字和原名字都正确
     4.指标二:Precision tp/(tp+fp)
     5.指标三:recall tp/(tp+fn)
     6.指标四：f1  (pre*recall)/(pre+recall)
     '''

     def evaluate(self, predict_names, original_names,train):
         # 原来trg_label 是 batch*[x,y,<eos>]
         # 首先获取预测的一些词
         if train:
            y = np.reshape(predict_names, [self.batch_size, -1, self.trg_vocab_size])  # 还原回[batch_size,填充,词表大小]
            # 先获取topk的数据 [batch_size,填充,1]而且直接就是词表中对应词的位置！
            y = np.reshape(np.argmax(y, axis=2), [self.batch_size, -1])
         else:
            #预测的时候得到的就是[batch_size,预测数]
            y = predict_names
         # 因为有填充所以需要去除填充的位置
         true_positive = 0
         false_positive = 0
         false_negative = 0
         num_correct_predictions = 0
         original_name2PreNames = []
         for i in range(self.batch_size):
             # 这里我们直接根据rnn_input_tensor_size 进行切片获取真正的字符个数 [1,t,tok]
             filtered_predicted_names = self.filter_impossible_names(np.reshape(y[i, :], [-1]))
             # shape [1,t] 输入是numpy
             filterPad_original_names = self.filter_impossible_names(np.reshape(original_names[i, :], [-1]))

             if not train:
                 # 解析出名字
                 #original_name2PreNames.append((", ".join([self.vocabs_map[int(i)] for i in filterPad_original_names]),
                                                #"__&&__", (", ".join(
                     #[self.vocabs_map[int(i)] for i in filtered_predicted_names]))))
                 pass

             # 全对的情况
             if filterPad_original_names == filtered_predicted_names or self.unique(
                     filterPad_original_names) == self.unique(
                     filtered_predicted_names) or ''.join(filterPad_original_names) == ''.join(
                 filtered_predicted_names):
                 num_correct_predictions += 1
             # 看看部分对

             if ''.join(filterPad_original_names) == ''.join(filtered_predicted_names):
                 true_positive += len(filterPad_original_names)
                 continue

             for subtok in filtered_predicted_names:
                 if subtok in filterPad_original_names:
                     true_positive += 1
                 else:
                     false_positive += 1
             for subtok in filterPad_original_names:
                 if not subtok in filtered_predicted_names:
                     false_negative += 1

         # 开始计算
         if true_positive + false_positive > 0:
             precision = true_positive / (true_positive + false_positive)
         else:
             precision = 0
         if true_positive + false_negative > 0:
             recall = true_positive / (true_positive + false_negative)
         else:
             recall = 0
         if precision + recall > 0:
             f1 = 2 * precision * recall / (precision + recall)
         else:
             f1 = 0

         return num_correct_predictions / self.batch_size, precision, recall, f1,original_name2PreNames

