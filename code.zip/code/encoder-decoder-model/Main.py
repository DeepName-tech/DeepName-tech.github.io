#coding=utf-8
from  Lenet5AddLSTM import Lenet5_LSTM
from   DataSeter import  DataSeter
import tensorflow as tf
import numpy as np
import time
import pandas as pd
import sys

'''
专门用来跑六百维度的数据
'''


if __name__ == '__main__':

    file_path = "/home/qwe/disk1/LRF/all_datas/data_2019_8_24/time6/raw_data_splited/"

    cnn_train_input_path = "".join((file_path, "train_data.csv"))
    rnn_train_input_path = "".join((file_path, "train_data_label.csv"))
    cnn_test_input_path = "".join((file_path, "test_data.csv"))
    rnn_test_input_path = "".join((file_path, "test_data_label.csv"))

    vocabs_map_path = None

    cnn_graph_size = 30
    batch_size = 200
    buffer_size = 600
    num_epochs = 140
    all_data_size = 156000 
    test_data_size = 14000 
    dataseter  = DataSeter(cnn_train_input_path,rnn_train_input_path,cnn_test_input_path,rnn_test_input_path)
    #cnn_data batch_size [-1,28] rnn_input [<sos>,x] batch * n
    cnn_train_data,(rnn_train_data,rnn_train_label,rnn_train_size) = dataseter.train_data(cnn_graph_size,batch_size,buffer_size,num_epochs)
    #测试集
    cnn_test_data, (rnn_test_data, rnn_test_label, rnn_test_size) = dataseter.test_data(cnn_graph_size, batch_size, buffer_size,num_epochs*(all_data_size//batch_size))

    input_tensor_placeholder = tf.placeholder(dtype=tf.float32, shape=[batch_size,900], name='cnn_train_data_name')
    rnn_train_data_placeholder = tf.placeholder(dtype=tf.int32, shape=[batch_size, None], name='rnn_train_data_name')
    rnn_train_label_placeholder = tf.placeholder(dtype=tf.int32, shape=[batch_size, None], name='rnn_train_label_name')
    rnn_train_size_placeholder = tf.placeholder(dtype=tf.int32, shape=[batch_size], name='rnn_train_size_name')

    # 模型需要的数据
    trg_vocab_size = 8089 #词表大小 数字10个加上 <sos> <eos>

    trg_vocab_embedding=np.array(pd.read_csv("".join((file_path,"tokens.csv")),header=-1).values,dtype=np.float32)

    regularizer = tf.contrib.layers.l2_regularizer(0.1)
    keep_prob = tf.placeholder(tf.float32, name='keep_prob_input')

    model = Lenet5_LSTM(cnn_graph_size,trg_vocab_size,trg_vocab_embedding,vocabs_map_path,batch_size,keep_prob)
    logits = model.inference(input_tensor_placeholder,2*300,rnn_train_data_placeholder,rnn_train_size_placeholder,regularizer,True)
    cost_op,train_op= model.train(logits,rnn_train_label_placeholder,rnn_train_size_placeholder,batch_size,all_data_size,trg_vocab_size)

    #建立评估模式
    #这个rnn_train_data_placeholder 只需要全1即可
    evaluate_logits = model.inference(input_tensor_placeholder,2*300, rnn_train_data_placeholder, rnn_train_size_placeholder,None, False)


    #保存模型
    saver = tf.train.Saver()
    merged = tf.summary.merge_all()

    MaxPrecision = sys.float_info.min
    MaxF1 = sys.float_info.min

    with tf.Session() as sess:
        summery_write = tf.summary.FileWriter("/home/qwe/disk1/LRF/codeClone/model/Model_814/method_split/20wan_datas/time6/logs/%s/"%time.time(), sess.graph)
        #从存储点恢复模型的参数
        sess.run(tf.global_variables_initializer())
        print("模型开始训练")
        for i in range(num_epochs*(all_data_size//batch_size)):
            try:
                _cnn_train_data, _rnn_train_data, _rnn_train_label, _rnn_train_size = sess.run(
                    [cnn_train_data, rnn_train_data, rnn_train_label, rnn_train_size])
                _, summery_str, _cost, _logits = sess.run([train_op, merged, cost_op, logits],
                                                          feed_dict={input_tensor_placeholder: _cnn_train_data,
                                                                     rnn_train_data_placeholder: _rnn_train_data,
                                                                     rnn_train_label_placeholder: _rnn_train_label,
                                                                     rnn_train_size_placeholder: _rnn_train_size,
                                                                     keep_prob: 0.5})
                if i%50==0 and i!=0:
                    print("After %d steps,per batch cost is %.3f"%(i,_cost))
                    _accuracy, _train_precision, _recall, _f1_train,_ = model.evaluate(_logits,_rnn_train_label,True)
                    print("After %d steps,per batch on trainData accuracy:%.3f,precision:%0.3f,recall:%0.3f,f1:%0.3f" % (
                            i, _accuracy, _train_precision, _recall, _f1_train))
                if i%100==0 and i!=0:
                    _precision_results = []
                    _recall_results = []
                    _f1_results = []
                    _accuracy_results = []
                    #测试集上测试
                    for j in range(test_data_size // batch_size):
                       _cnn_test_data, _rnn_test_data, _rnn_test_label, _rnn_test_size = sess.run([cnn_test_data, rnn_test_data, rnn_test_label, rnn_test_size])
                       _evaluate_logits = sess.run(evaluate_logits, feed_dict={input_tensor_placeholder: _cnn_test_data,
                                                                               rnn_train_data_placeholder:np.ones(shape=[batch_size,1]),
                                                                               rnn_train_size_placeholder: _rnn_test_size,
                                                                               keep_prob: 1.0})
                       _accuracy, _test_precision, _recall, _f1_test,_ = model.evaluate(_evaluate_logits, _rnn_test_label,False)
                       _precision_results.append(_test_precision)
                       _recall_results.append(_recall)
                       _f1_results.append(_f1_test)
                       _accuracy_results.append(_accuracy)
                    if np.array(_precision_results).mean()> 0.40 and np.array(_f1_results).mean() > MaxF1 and i > 1000:
                       MaxF1 = np.array(_f1_results).mean()
                       MaxPrecision = np.array(_precision_results).mean()
                       print("After %d steps,保存:accuracy:%0.3f,precision:%0.3f,recall:%0.3f,f1:%0.3f" % (i, np.array(_accuracy_results).mean(), np.array(_precision_results).mean(),np.array(_recall_results).mean(), np.array(_f1_results).mean()))
                       saver.save(sess, "/home/qwe/disk1/LRF/codeClone/model/Model_814/method_split/20wan_datas/time6/ckpt/Transformer.ckpt", global_step=i)
                    print("After %d steps:accuracy:%0.3f,precision:%0.3f,recall:%0.3f,f1:%0.3f" % (i, np.array(_accuracy_results).mean(),np.array(_precision_results).mean(),np.array(_recall_results).mean(), np.array(_f1_results).mean()))
                summery_write.add_summary(summery_str)
            except tf.errors.OutOfRangeError as e:
                  print("全部执行完毕")
                  break
    summery_write.close()
