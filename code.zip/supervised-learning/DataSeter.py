#coding=utf-8
import tensorflow as tf

class DataSeter:



    def __init__(self,cnn_train_input_path,rnn_train_input_path,cnn_test_input_path,rnn_test_input_path):
        '''
        初始化数据集
        :param cnn_input: 所有的方法的jimple表示和natural信息 allmethod_size * 256(128) 也就是数据处理的时候吧图片转成一行，这样rnn也能对应上
        :param rnn_input: 每个jimple体对应的方法名字的编号 [[X,Y,Z,<eos>],[X,Y,G,<eos>]]==》[[2,3,4],[2,3,6]] allmethod_size * n(句子长度)
        '''
        self.cnn_train_dataset = tf.data.TextLineDataset(cnn_train_input_path)
        self.rnn_train_dataset = tf.data.TextLineDataset(rnn_train_input_path)
        '''
        测试集数据集
        '''
        self.cnn_test_dataset = tf.data.TextLineDataset(cnn_test_input_path)
        self.rnn_test_dataset = tf.data.TextLineDataset(rnn_test_input_path)

        self.SOS_ID = 1

    def train_data(self,cnn_graph_size,batch_size,buffer_size,num_epochs):
        '''
        返回训练数据 cnn_输入,rnn_输入,rnn_size,rnn_label
        注意rnn这一块 都是用对应词汇的编码（从1开始）而不是对应的embedding
        :param cnn_graph_size cnn图的列的个数
        :param batch_size:  batch大小
        :param buffer_size:  混淆的缓冲区大小
        :param num_epochs: 迭代的次数
        :return: cnn_输入,rnn_输入,rnn_size,rnn_label
        '''
        train_dataset = tf.data.Dataset.zip((self.cnn_train_dataset, self.rnn_train_dataset))

        #先把rnn的一行数据切分开，变成一维的数组，这样做填充的时候
        train_dataset = train_dataset.map(lambda *datas:(datas[0],tf.string_to_number(tf.string_split([datas[1]], delimiter=',').values,tf.int32)))

        def make_rnninput(*line_data):
            # rnn 整个句子
            rnn_data = line_data[1]
            trg_len = tf.size(rnn_data)
            # 文件默认有eos 现在加入sos，默认就是label 答案
            trg_input = tf.concat([[self.SOS_ID], rnn_data[:-1]], axis=0)
            # 返回数组
            return (line_data[0]),(trg_input, rnn_data, trg_len)
        #先把rnn的解决了 输入 输出 size
        train_dataset = train_dataset.map(make_rnninput)
        #rnn 填充 cnn 由于batch 组合还是一维 不需要填充，因为每个维度都是数字[b'12',b'23']
        padded_shapes = ((tf.TensorShape([])),(tf.TensorShape([None]), tf.TensorShape([None]), tf.TensorShape([])))
        train_dataset = train_dataset.shuffle(buffer_size).padded_batch(batch_size,padded_shapes)
        #train_dataset = train_dataset.padded_batch(batch_size, padded_shapes)

        #现在需要把cnn的数据变成[batch*[-1,256]] 维度
        def make_cnninput(*line_data):
            result = []
            cnn_data = line_data[0]
            for i in range(batch_size):
                result.append(tf.string_to_number(tf.string_split([cnn_data[i]], delimiter=',').values,tf.float32))
            return result,line_data[1]
        train_dataset = train_dataset.map(make_cnninput)
        train_dataset = train_dataset.repeat(num_epochs)
        iterator = train_dataset.make_one_shot_iterator()
        return iterator.get_next()

    def test_data(self, cnn_graph_size, batch_size, buffer_size, num_epochs):
        '''
        返回训练数据 cnn_输入,rnn_输入,rnn_size,rnn_label
        注意rnn这一块 都是用对应词汇的编码（从1开始）而不是对应的embedding
        :注意 dataset的shuffle在获取batch之前，所以cnn+rnn数据先zip，但是cnn又不能填充，只能先不进行字符串切割，保持所有cnn都是数字，不用填充
        :param cnn_graph_size cnn图的列的个数
        :param batch_size:  batch大小
        :param buffer_size:  混淆的缓冲区大小
        :param num_epochs: 迭代的次数
        :return: cnn_输入,rnn_输入,rnn_size,rnn_label
        '''
        test_dataset = tf.data.Dataset.zip((self.cnn_test_dataset, self.rnn_test_dataset))

        # 先把rnn的一行数据切分开，变成一维的数组，这样做填充的时候
        test_dataset = test_dataset.map(lambda *datas: (datas[0], tf.string_to_number(tf.string_split([datas[1]], delimiter=',').values,tf.int32)))

        def make_rnninput(*line_data):
            # rnn 整个句子
            rnn_data = line_data[1]
            trg_len = tf.size(rnn_data)
            # 文件默认有eos 现在加入sos，默认就是label 答案
            trg_input = tf.concat([[self.SOS_ID], rnn_data[:-1]], axis=0)
            # 返回数组
            return (line_data[0]), (trg_input, rnn_data, trg_len)

        # 先把rnn的解决了 输入 输出 size
        test_dataset = test_dataset.map(make_rnninput)
        # rnn 填充 cnn 由于batch 组合还是一维 不需要填充，因为每个维度都是数字[b'12',b'23']
        padded_shapes = ((tf.TensorShape([])), (tf.TensorShape([None]), tf.TensorShape([None]), tf.TensorShape([])))
        test_dataset = test_dataset.shuffle(buffer_size).padded_batch(batch_size, padded_shapes)
        #test_dataset = test_dataset.padded_batch(batch_size, padded_shapes)
        # 现在需要把cnn的数据变成[batch*[-1,256]] 维度
        def make_cnninput(*line_data):
            result = []
            cnn_data = line_data[0]
            for i in range(batch_size):
                result.append(tf.string_to_number(tf.string_split([cnn_data[i]], delimiter=',').values,tf.float32))
            return result, line_data[1]

        test_dataset = test_dataset.map(make_cnninput)
        test_dataset = test_dataset.repeat(num_epochs*10)
        iterator = test_dataset.make_one_shot_iterator()
        return iterator.get_next()


if __name__ == '__main__':
    cnn_train_input_path = "train_data.csv"
    rnn_train_input_path = "train_data_label.csv"
    cnn_test_input_path = "test_data.csv"
    rnn_test_input_path = "test_data_label.csv"
    cnn_graph_size = 28
    batch_size = 500
    buffer_size = 200
    num_epochs = 2
    dataseter = DataSeter(cnn_train_input_path, rnn_train_input_path, cnn_test_input_path, rnn_test_input_path)
    # cnn_data batch_size [-1,28] rnn_input [<sos>,x] batch * n
    cnn_train_data, (rnn_train_data, rnn_train_label, rnn_train_size) = dataseter.train_data(cnn_graph_size,
                                                                                             batch_size,
                                                                                             buffer_size,
                                                                                             num_epochs)
    # 加一步 字符串数据转int
    # cnn_train_data = tf.string_to_number(cnn_train_data, tf.float32)
    # rnn_train_data = tf.string_to_number(rnn_train_data, tf.int32)
    # rnn_train_label = tf.string_to_number(rnn_train_label, tf.int32)

    import numpy as np
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        for i in range(70000):
            if(i>34700):
                print("当前")
            try:
               cnn_data,rnn_data = sess.run([cnn_train_data,rnn_train_data])
            except tf.errors.OutOfRangeError:
                print("数据全部执行完")
                break
            #print(cnn_data,rnn_data)
            print("当前次数%d"%i)

    # from tensorflow.examples.tutorials.mnist import input_data
    #
    # mnist = mnist = input_data.read_data_sets('/home/qwe/LiRongFan_Lab/NN/MethodNamePredicter/datas/MNIST_data')
    #
    # #print(mnist.train.next_batch(1))
    #
    # import  pandas as pd
    #
    # cnn_train_data_pd = pd.read_csv("train_data.csv")
    # cnn_train_data_label_pd = pd.read_csv("train_data_label.csv")
    # all_minist_pd = pd.concat([cnn_train_data_pd,cnn_train_data_label_pd.iloc[:,0]],axis=1)
    #
    #
    #
    # def _next_batch(data, batch_size):
    #     indexs = np.random.randint(0, data.shape[0], batch_size)
    #     aim_data = data.iloc[indexs]
    #     return aim_data.iloc[:, 0:784], aim_data.iloc[:, 784]
    #
    #
    # X_batch, y_batch = _next_batch(all_minist_pd, batch_size)
    #
    # print(X_batch.values,y_batch.values)

    # with open("/home/qwe/LiRongFan_Lab/pycharm_projects/MethodNamePredicter/train_data_label.csv") as train_labels_file:
    #     while (True):
    #         label = train_labels_file.readline()
    #         if (len(label) > 0):
    #             if (len(label.split(",")) < 2):
    #                 print(label + "有")
    #                 print(label)
    #         else:
    #             break