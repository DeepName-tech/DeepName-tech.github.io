#coding=utf-8
import numpy as np
'''
结果评估:保存预测结果信息
1.第一个词预测正确的方法的索引是哪些？索引是方法在文件中位置 从1开始！下同
2.全对的词预测正确的方法的索引是哪些？
3.只要有对的词的方法的索引是哪些？
4.全不对的词的方法的索引是哪些？
5.有错的词的方法的索引是哪些？
'''

class ResultEvaluate:

    def __init__(self,path):
        self.sos_id = 1
        self.eos_id = 2
        self.unk = 3
        self.pad = 0
        self._first_right_indexes = set()
        self._all_right_indexes = set()
        self._some_right_indexes = set()
        self._all_wrong_indexes = set()
        self._some_wrong_indexes = set()
        # contain 就是只看预测的名字包含原来名字，也就是我们预测多了的案列
        self._contain_original_indexes = set()
        #生成文件所输出的路径
        self.path = path


    def evaluate(self,original_names,predicted_names,output_names_flag=False,vocabs_map=None):
        '''
        输入两个名字信息，注意传进来的是全部测试集
        :param original_names: 原始的名字 type:list数组 [array(),array()]
        :param predicted_names: 预测出来的名字 type:list数组 [array(),array()]
        :param output_names:bool 是否输出预测出来的名字信息
        :return: 5个指标
        '''
        all_array_size = len(original_names) #一共多少个batch
        _preNames = []
        _vocabs_map = []
        #统计所有预测的名字索引编号
        _predict_name_indexes = []
        #加载词汇编号
        if output_names_flag:
            _vocabs_map = self.findVocabMap(vocabs_map)  # 词汇的编号

        current_sample = 0

        for i in range(all_array_size):
            #获取batch_size
            for j in range(original_names[i].shape[0]):
                current_sample+=1
                # 这里我们直接根据rnn_input_tensor_size 进行切片获取真正的字符个数 [1,t,tok]
                filtered_predicted_names = self.filter_impossible_names(np.reshape(predicted_names[i][j, :], [-1]))
                # shape [1,t] 输入是numpy
                filterPad_original_names = self.filter_impossible_names(np.reshape(original_names[i][j, :], [-1]))

                if len(filtered_predicted_names) > 0:
                    _predict_name_indexes.append(",".join(filtered_predicted_names))
                else:
                    _predict_name_indexes.append("没有预测")

                #如果需要输出预测的全部名单
                if output_names_flag:
                    if len(filtered_predicted_names) > 0:
                       _preNames.append(", ".join([_vocabs_map[int(k)] for k in filtered_predicted_names]))
                    else:
                       _preNames.append("没有预测")

                #全对情况下,也就是第i个值 预测名和原名字都相同
                #全对加上只要遇到2就停止
                filtered_predicted_names_stop = self.filter_stop2_names(np.reshape(predicted_names[i][j, :], [-1]))
                filterPad_original_names_stop = self.filter_stop2_names(np.reshape(original_names[i][j, :], [-1]))

                if filterPad_original_names_stop == filtered_predicted_names_stop or self.unique(
                        filterPad_original_names_stop) == self.unique(
                    filtered_predicted_names_stop) or ''.join(filterPad_original_names_stop) == ''.join(
                    filtered_predicted_names_stop):
                    self._all_right_indexes.add(str(current_sample))
                    #全对，那第一个词肯定对
                    self._first_right_indexes.add(str(current_sample))
                    #有队的
                    self._some_right_indexes.add(str(current_sample))
                    #全对的也包含原始名字
                    self._contain_original_indexes.add(str(current_sample))
                    continue

                # 只要第一个相等
                if len(filtered_predicted_names) > 0 and len(filterPad_original_names)>0 :
                    if filtered_predicted_names[0] == filterPad_original_names[0]:
                        self._first_right_indexes.add(str(current_sample))
                        self._some_right_indexes.add(str(current_sample))

                for subtok in filtered_predicted_names:
                    #第一个不相等，就看这个词是否有
                    if subtok in filterPad_original_names:
                        self._some_right_indexes.add(str(current_sample))
                    else:
                        #只要预测的有错误的词
                        self._some_wrong_indexes.add(str(current_sample))

                #我们预测的名字包含了原来的名字
                for subtok in filterPad_original_names:
                    if subtok not in filtered_predicted_names:
                        break
                else:
                    self._contain_original_indexes.add(str(current_sample))

                for subtok in filtered_predicted_names:
                    if subtok in filterPad_original_names:
                        break
                else:
                    #全错的
                    self._all_wrong_indexes.add(str(current_sample))

        with open(self.path+"/result_indexes.txt",'w+') as result_index:
            result_index.write("%s:%s\r\n" % ("first_right_indexes",",".join(self._first_right_indexes)))
            result_index.write("%s:%s\r\n" % ("_all_right_indexes", ",".join(self._all_right_indexes)))
            result_index.write("%s:%s\r\n" % ("_some_right_indexes", ",".join(self._some_right_indexes)))
            result_index.write("%s:%s\r\n" % ("_all_wrong_indexes", ",".join(self._all_wrong_indexes)))
            result_index.write("%s:%s\r\n" % ("_some_wrong_indexes", ",".join(self._some_wrong_indexes)))
            result_index.write("%s:%s\r\n" % ("_contain_original_indexes", ",".join(self._contain_original_indexes)))

        with open(self.path + "/predict_indexes.txt", 'w+') as predict_indexes:
            for index in _predict_name_indexes:
                predict_indexes.write("%s\r\n"%index)

        # 把所有的预测的名字都写入文件中
        if output_names_flag:
            for names in _preNames:
                with open(self.path + "/predict_names_word.txt", "w+") as  predict_names_word:
                    predict_names_word.write("%s\r\n" % names)


    def filter_impossible_names(self, names_list):
        '''
        输入的是name的数字list [3,2,1,7]
        :param names_list:
        :return:
        '''
        result = []

        for name in names_list:
            if name not in [self.sos_id, self.eos_id, self.unk, self.pad]:
                result.append(str(name))
        return result

    def filter_stop2_names(self, names_list):
        '''
        输入的是name的数字list [3,2,1,7]
        :param names_list: 预测的数
        :return: 预测2的位置之前的词，也就是遇到2就是停
        '''
        result = []
        for name in names_list:
            if name == 2:
                break
            if name not in [self.sos_id, self.eos_id, self.unk, self.pad]:
                result.append(str(name))
        return result

    def unique(self, sequence):
        unique = []
        [unique.append(str(item)) for item in sequence if item not in unique]
        return unique

    # 解析出每个编号对应的词
    def findVocabMap(self, file):
        vocabs_map = {}
        if file!=None:
            with open(file) as vocab_file:
                datas = vocab_file.readline()
                while (len(datas) > 0):
                    datas = datas.split()
                    vocabs_map[int(datas[1])] = datas[0]
                    datas = vocab_file.readline()
        return vocabs_map
